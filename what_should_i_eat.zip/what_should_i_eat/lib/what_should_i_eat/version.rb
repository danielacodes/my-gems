module WhatShouldIEat
  VERSION = "0.1.0"
end
